# LEOHS: Landsat ETM+ OLI Harmonization Script
# Copyright (C) 2025 Galen Richardson
# This file is licensed under GPL-3.0-or-later
# Related Publication: https://doi.org/10.1080/10106049.2025.2538108
import numpy as np
import pandas as pd
import geopandas as gpd
import rasterio,random
from shapely.geometry import Point, shape, mapping
from datetime import datetime
from rasterio.features import geometry_mask
from joblib import Parallel, delayed
from .io import time_tracker, create_save_path
from .wrs import create_WRS_gdf

def generate_equalA_points (AOI,points_n):
    AOI=AOI.to_crs('EPSG:8857')#make into equal earth projection for even global sampling
    transform=rasterio.transform.from_bounds(*AOI.total_bounds,10000,10000)#creates a raster grid
    mask=geometry_mask([geom for geom in AOI.geometry], transform=transform, invert=True, out_shape=(10000,10000))#creates masked raster grid
    rows, cols=np.where(mask)#Sample points from zthe mask raster grid
    random_indices=np.random.choice(len(rows), size=points_n, replace=False)
    sampled_rows,sampled_cols=rows[random_indices],cols[random_indices]
    x_coords, y_coords=rasterio.transform.xy(transform, sampled_rows, sampled_cols)
    points=[Point(x, y) for x, y in zip(x_coords, y_coords)]#Create points from the sampled coordinates
    points_gdf=gpd.GeoDataFrame(geometry=points, crs='EPSG:8857')
    return points_gdf
def find_nearest_polygon_and_generate_point(WRS_gdf, point):
    point = gpd.GeoSeries([point], crs=WRS_gdf.crs)#Ensure the point is in the same CRS as the polygons and AOI
    WRS_gdf['distance']=WRS_gdf['geometry'].distance(point.iloc[0])#Calculate the distance from the point to each polygon in WRS_gdf
    nearest_polygon=WRS_gdf.loc[WRS_gdf['distance'].idxmin()]['geometry']#Find the polygon with the minimum distance
    minx, miny, maxx, maxy=nearest_polygon.bounds #Generate a random point within the intersection polygon
    while True:
        random_point=Point(random.uniform(minx, maxx), random.uniform(miny, maxy))
        if nearest_polygon.contains(random_point):
            return random_point
def process_points(aoi_points,overlap_gdf):
    overlap_gdf=overlap_gdf.to_crs('EPSG:8857')#Project to equal earth
    new_points=[]
    AOI_array=np.array([(point.x, point.y) for point in aoi_points.geometry])#Make AOI array for distance calculations
    for point_array in AOI_array:
        point=Point(point_array[0], point_array[1])
        if overlap_gdf.contains(point).any():
            new_points.append(point)#Append point if it is inside a WRS tile
        else:
            alt_point=find_nearest_polygon_and_generate_point(overlap_gdf, point)#If not, find closest alternative
            new_points.append(alt_point)#Append the alt point to the list directly
    return gpd.GeoDataFrame(geometry=new_points, crs='EPSG:8857')
def parallel_process_points(aoi_points,frequency_gdf,full_AOI,num_cores):
    full_AOI=full_AOI.to_crs('EPSG:8857')
    frequency_gdf=frequency_gdf.to_crs('EPSG:8857')
    clip_gdf=gpd.clip(frequency_gdf, full_AOI) #clipping frequency_gdf to AOI
    clip_gdf=clip_gdf.to_crs('EPSG:8857') # making it equal area
    clip_gdf=clip_gdf.explode().reset_index(drop=True) #removing multipolygons
    clip_gdf = clip_gdf[clip_gdf.geom_type == 'Polygon'].reset_index(drop=True)  # drop line/point pieces from clip
    point_count=len(aoi_points)
    subset_size=max(point_count // num_cores, 1)
    aoi_subsets=[aoi_points.iloc[i:i + subset_size] for i in range(0, point_count, subset_size)]
    results = Parallel(n_jobs=num_cores)(
        delayed(process_points)(aoi_subset, clip_gdf) for aoi_subset in aoi_subsets)
    combined_gdf=gpd.GeoDataFrame(pd.concat(results, ignore_index=True))
    combined_gdf=combined_gdf.to_crs('EPSG:4326')#Convert back to WGS 84
    return combined_gdf
def create_overlap_points_gdf(points_gdf, WRS_gdf):
    points_gdf=points_gdf.to_crs(WRS_gdf.crs)
    joined_gdf=gpd.overlay(points_gdf, WRS_gdf[['geometry', 'LS7_row', 'LS7_path', 'LS8_path']], how='intersection')
    joined_gdf=joined_gdf[['LS7_row', 'LS7_path', 'LS8_path', 'geometry']]
    joined_gdf=joined_gdf.sample(frac=1).reset_index(drop=True)
    joined_gdf=joined_gdf.drop_duplicates(subset='geometry')
    return joined_gdf.reset_index(drop=True)
def create_sampling_points(full_AOI,sample_points_n,frequency_gdf,num_cores,logs,max_rounds=100):
    t0 = datetime.now()
    parts,n_points=[],0
    for _ in range(max_rounds):#keep creating points until sample_points_n points have path/row information
        AOI_points=generate_equalA_points(full_AOI,sample_points_n-n_points)#makes random points in equal earth prj
        new_points=parallel_process_points(AOI_points,frequency_gdf,full_AOI,num_cores)#moves points inside WRS tiles
        parts.append(create_overlap_points_gdf(new_points,frequency_gdf))#appends path/row information to points
        overlap_points_gdf=pd.concat(parts,ignore_index=True).drop_duplicates(subset='geometry')
        n_points=len(overlap_points_gdf)
        if n_points>=sample_points_n:
            break
    overlap_points_gdf=gpd.GeoDataFrame(overlap_points_gdf.iloc[:sample_points_n].reset_index(drop=True),geometry='geometry',crs='EPSG:4326')
    if len(overlap_points_gdf)<sample_points_n:
        print(f"Warning: only {len(overlap_points_gdf)} of {sample_points_n} sampling points could be created")
        logs.append(f"Warning: only {len(overlap_points_gdf)} of {sample_points_n} sampling points could be created")
    Sample_points_gdf=overlap_points_gdf[['geometry']].copy()
    logs.append(f"Number of sampling points created: {len(overlap_points_gdf)}")
    logs.append(f"Sampling points created in {time_tracker(t0)}")
    return Sample_points_gdf,overlap_points_gdf,logs
def create_composite_sampling_points(Aoi_shp_path,wrs_shp_path,Save_folder_path,sample_points_n,num_cores,logs):
    t0 = datetime.now()
    WRS_gdf,full_AOI=create_WRS_gdf(Aoi_shp_path,wrs_shp_path,Save_folder_path,logs)#same AOI/WRS prep as image pairs
    if WRS_gdf.empty:
        print("No matches available.\nAOI does not intersect any WRS overlap areas.")
        return None,full_AOI,logs
    WRS_gdf=WRS_gdf.rename(columns={'row1':'LS7_row','path1':'LS7_path','path2':'LS8_path'}).drop_duplicates(subset='geometry')
    _,Sample_points_gdf,logs=create_sampling_points(full_AOI,sample_points_n,WRS_gdf,num_cores,logs)#whole AOI, outside points moved to nearest overlap
    return Sample_points_gdf,full_AOI,logs
def get_sampling_points(Aoi_shp_path,wrs_shp_path,Save_folder_path,sample_points_n,full_AOI,frequency_gdf,num_cores,composite_models,logs):
    if composite_models is False:
        return create_sampling_points(full_AOI,sample_points_n,frequency_gdf,num_cores,logs) #returns Sample_points_gdf, overlap_points_gdf, logs
    return create_composite_sampling_points(Aoi_shp_path,wrs_shp_path,Save_folder_path,sample_points_n,num_cores,logs) #returns Sample_points_gdf, full_AOI, logs
