# LEOHS: Landsat ETM+ OLI Harmonization Script
# Copyright (C) 2025 Galen Richardson
# This file is licensed under GPL-3.0-or-later
# Related Publication: https://doi.org/10.1080/10106049.2025.2538108
import ee,time,random
import pandas as pd
import numpy as np
import geopandas as gpd
from joblib import Parallel, delayed
from ee.ee_exception import EEException
from .sampling import get_unique_combinations_as_dicts, filter_gdf_by_values, make_join_gdf, remove_outliers, update_df
EPS=1e-10 #floor for ratio denominators, prevents division by zero
SCALE,OFFSET=0.0000275,-0.2 #SR reflectance scale/offset
CFMASK_VALUES=[5440,21824] #Clear with lows set or mild cloud conf, LS7/LS8
WATER_VALUES=[5504,21952] #Water with lows set, LS7/LS8
SNOW_VALUES=[13600,30048] #High conf snow/ice, LS7/LS8
RADSAT_BITMASK=0b01111111 #bits 0-6 saturation check
ATMOS_OPACITY_SCALE=0.001
MAX_DN=65455
BATCH_SIZE=250 #points per reduceRegions request
MAX_FEATURES=5000 #GEE limit on features returned per request
RATE_LIMIT_MSGS=("Too Many Requests","Too many concurrent aggregations") #GEE 429 errors to retry
HIGH_VOLUME_URL='https://earthengine-highvolume.googleapis.com' #GEE endpoint for many parallel requests
BAND_NAMES=['B','G','R','NIR','SWIR1','SWIR2'] #bands shared by ETM+ and OLI
L7_BAND_NUMS=['1','2','3','4','5','7'] #ETM+, matches fix_column_names
L8_BAND_NUMS=['2','3','4','5','6','7'] #OLI without CA, matches fix_column_names

def get_refl_bands(collection_id,band_nums):
    prefix='' if 'TOA' in collection_id else 'SR_'
    return [f'{prefix}B{n}' for n in band_nums]
#composites --------------------------------------------------------------
def median_composite(df):
    return df[BAND_NAMES].median()#per-band median
def mean_composite(df):
    return df[BAND_NAMES].mean()#per-band mean
def percentile_composite(df,q):
    return df[BAND_NAMES].quantile(q/100)#per-band percentile, linear interpolation
def select_observation(df,score,best):
    score=np.asarray(score,dtype=float)
    score=np.where(np.isfinite(score),score,-np.inf if best=='max' else np.inf)#NaN/inf scores can never be selected
    target=score.max() if best=='max' else score.min()
    i=int(np.flatnonzero(np.isclose(score,target,rtol=0,atol=EPS))[0])#ties go to the first observation
    return df[BAND_NAMES].iloc[i]#all bands from one observation
def max_ndvi_composite(df):
    ndvi=(df['NIR']-df['R'])/np.maximum(df['NIR']+df['R'],EPS)#NDVI=(NIR-R)/(NIR+R)
    return select_observation(df,ndvi,'max')
def max_rnb_composite(df):
    rnb=df['NIR']/np.maximum(df['B'],EPS)#RNB=NIR/Blue
    return select_observation(df,rnb,'max')
def medoid_composite(df):
    x=df[BAND_NAMES].to_numpy(float)
    dist=np.sqrt(((x[:,None,:]-x[None,:,:])**2).sum(axis=2)).sum(axis=1)#sum of Euclidean distances to all observations
    return select_observation(df,dist,'min')
def nlcd_composite(df):
    x=df[BAND_NAMES].to_numpy(float)
    dist=((x-np.nanmedian(x,axis=0))**2).sum(axis=1)#sum of squared differences to per-band pseudo median
    return select_observation(df,dist,'min')
COMPOSITE_FUNCS={'median':median_composite,'mean':mean_composite,'max_ndvi':max_ndvi_composite,
                 'max_rnb':max_rnb_composite,'medoid':medoid_composite,'nlcd':nlcd_composite} #lower case, must match VALID_COMPOSITE_METHODS in io.py
#composites --------------------------------------------------------------
def build_mask_fn(refl_bands,CFMask_filtering,SR_ATMOS_OPACITY_filtering,Water,Snow,has_atmos_opacity):
    is_SR=refl_bands[0].startswith('SR_')
    allowed=list(CFMASK_VALUES)
    if Water: allowed=allowed+WATER_VALUES
    if Snow: allowed=allowed+SNOW_VALUES
    def mask_fn(image):
        raw=image.select(refl_bands)
        mask=raw.lte(MAX_DN).reduce(ee.Reducer.min()) #condition_numeric
        mask=mask.And(image.select('QA_RADSAT').bitwiseAnd(RADSAT_BITMASK).eq(0)) #filter_sat_by_bits
        if CFMask_filtering:
            qa=image.select('QA_PIXEL')
            qa_mask=qa.eq(allowed[0])
            for v in allowed[1:]:
                qa_mask=qa_mask.Or(qa.eq(v))
            mask=mask.And(qa_mask)
        refl=raw.multiply(SCALE).add(OFFSET) if is_SR else raw
        mask=mask.And(refl.gte(0).And(refl.lte(1)).reduce(ee.Reducer.min())) #filter_out_of_range_sr
        if has_atmos_opacity and SR_ATMOS_OPACITY_filtering is not False:
            mask=mask.And(image.select('SR_ATMOS_OPACITY').multiply(ATMOS_OPACITY_SCALE).lt(SR_ATMOS_OPACITY_filtering))
        return ee.Image(refl.rename(BAND_NAMES).updateMask(mask).copyProperties(image,['system:time_start']))
    return mask_fn
def date_filter(months,years):
    ranges=[]
    for y in years:
        for m in months:
            end=f'{y+1}-01-01' if m==12 else f'{y}-{m+1:02d}-01'
            ranges.append(ee.Filter.date(f'{y}-{m:02d}-01',end))
    return ee.Filter.Or(*ranges)
def filter_collection(collection,months,years,maxCloudCover,path,row):
    return collection.filter(date_filter(months,years)).filter(ee.Filter.eq('WRS_PATH',path)) \
                     .filter(ee.Filter.eq('WRS_ROW',row)).filter(ee.Filter.lte('CLOUD_COVER',maxCloudCover))
def ee_getinfo(ee_obj,max_retries=10):
    attempt=0
    while attempt<=max_retries:
        try:
            return ee_obj.getInfo()
        except EEException as e:
            if any(m in str(e) for m in RATE_LIMIT_MSGS):
                print(f"[Attempt {attempt+1}/{max_retries}] Rate limit hit. Waiting...")
                time.sleep(random.uniform(10,30)*(attempt+1))#back off longer each retry
                attempt+=1
            else:
                raise
        except Exception as e:
            print(f"[Attempt {attempt+1}/{max_retries}] Unexpected error: {e}")
            time.sleep(random.uniform(60,120))
            attempt+=1
    raise RuntimeError(f"Failed after {max_retries} retries due to rate limits.")
def get_scene_ids(LS7,LS8,months,years,maxCloudCover,L7_path,L8_path,row):
    L7_ids=filter_collection(ee.ImageCollection(LS7),months,years,maxCloudCover,L7_path,row).aggregate_array('system:id')
    L8_ids=filter_collection(ee.ImageCollection(LS8),months,years,maxCloudCover,L8_path,row).aggregate_array('system:id')
    return ee_getinfo(ee.List([L7_ids,L8_ids]))#one request per tile for both sensors
def sample_region(masked_col,points,idx):
    fc=ee.FeatureCollection([ee.Feature(ee.Geometry.Point(points[i].x,points[i].y),{'pt':int(i)}) for i in idx])
    sampled=masked_col.map(lambda img: img.reduceRegions(collection=fc,reducer=ee.Reducer.mean(),scale=30)).flatten()
    feats=ee_getinfo(sampled.filter(ee.Filter.notNull(BAND_NAMES)))['features']#masked pixels dropped server side
    if not feats:
        return pd.DataFrame()
    df=pd.DataFrame([f['properties'] for f in feats])
    df[BAND_NAMES]=df[BAND_NAMES].apply(pd.to_numeric,errors='coerce')
    return df[['pt']+BAND_NAMES].dropna()
def composite_row(df,composite_models):
    df=df[BAND_NAMES].replace([np.inf,-np.inf],np.nan).dropna()#only finite observations are composited
    if composite_models.startswith('p_'):
        return percentile_composite(df,float(composite_models[2:]))
    if composite_models not in COMPOSITE_FUNCS:
        raise NotImplementedError(f"Composite method '{composite_models}' not yet implemented")
    return COMPOSITE_FUNCS[composite_models](df)
def composite_points(df,points,composite_models):
    rows,geoms=[],[]
    for pt,obs in df.groupby('pt'):
        rows.append(composite_row(obs,composite_models))
        geoms.append(points[int(pt)])
    return gpd.GeoDataFrame(pd.DataFrame(rows).reset_index(drop=True),geometry=geoms,crs='EPSG:4326')
def sample_batch(points,L7_col,L8_col,composite_models):
    L7_df=sample_region(L7_col,points,range(len(points)))
    if L7_df.empty:
        return None
    L8_df=sample_region(L8_col,points,sorted(L7_df['pt'].unique()))#sample LS8 with only valid LS7 observations
    if L8_df.empty:
        return None
    L7_gdf=composite_points(L7_df,points,composite_models)
    L8_gdf=composite_points(L8_df,points,composite_models)
    return make_join_gdf(L7_gdf,L8_gdf)
def get_pix_values_comp(filtered_points,L7_col,L8_col,n_scenes,composite_models):
    all_joined_pix_gdf=gpd.GeoDataFrame()
    points=list(filtered_points.geometry)
    batch=max(1,min(BATCH_SIZE,MAX_FEATURES//n_scenes))#stay under GEE feature limit
    for i in range(0,len(points),batch):
        batch_gdf=sample_batch(points[i:i+batch],L7_col,L8_col,composite_models)
        all_joined_pix_gdf=update_df(all_joined_pix_gdf,batch_gdf)
    return all_joined_pix_gdf
def process_chunk_big_gdf_comp(chunk,Sample_points_gdf,LS7,LS8,months,years,composite_models,maxCloudCover,
                               CFMask_filtering,SR_ATMOS_OPACITY_filtering,Water,Snow,project_ID):
    if project_ID != None:
        ee.Initialize(project=project_ID,opt_url=HIGH_VOLUME_URL)
    else:
        ee.Initialize(opt_url=HIGH_VOLUME_URL)
    L7_mask=build_mask_fn(get_refl_bands(LS7,L7_BAND_NUMS),CFMask_filtering,SR_ATMOS_OPACITY_filtering,Water,Snow,has_atmos_opacity=True)
    L8_mask=build_mask_fn(get_refl_bands(LS8,L8_BAND_NUMS),CFMask_filtering,SR_ATMOS_OPACITY_filtering,Water,Snow,has_atmos_opacity=False)
    chunk_gdf=gpd.GeoDataFrame()
    for unique_row_path in chunk:
        filtered_points=filter_gdf_by_values(Sample_points_gdf,unique_row_path)
        row,L7_path,L8_path=int(unique_row_path['LS7_row']),int(unique_row_path['LS7_path']),int(unique_row_path['LS8_path'])
        L7_ids,L8_ids=get_scene_ids(LS7,LS8,months,years,maxCloudCover,L7_path,L8_path,row)
        if not L7_ids or not L8_ids:#no scenes for one sensor on this tile
            continue
        L7_col=ee.ImageCollection.fromImages([ee.Image(i) for i in L7_ids]).map(L7_mask)
        L8_col=ee.ImageCollection.fromImages([ee.Image(i) for i in L8_ids]).map(L8_mask)
        joined_pix_gdf=get_pix_values_comp(filtered_points,L7_col,L8_col,max(len(L7_ids),len(L8_ids)),composite_models)
        if joined_pix_gdf is not None and not joined_pix_gdf.empty:
            chunk_gdf=update_df(chunk_gdf,joined_pix_gdf)
        time.sleep(0.5)
    return chunk_gdf
def create_big_gdf(Sample_points_gdf,LS7,LS8,months,years,composite_models,maxCloudCover,num_cores,
                   CFMask_filtering,SR_ATMOS_OPACITY_filtering,Water,Snow,logs,project_ID):
    unique_row_path_list=get_unique_combinations_as_dicts(Sample_points_gdf)
    chunks=[unique_row_path_list[i::num_cores] for i in range(num_cores)]
    gdfs=Parallel(n_jobs=num_cores)(
        delayed(process_chunk_big_gdf_comp)(chunk,Sample_points_gdf,LS7,LS8,months,years,composite_models,maxCloudCover,
                                            CFMask_filtering,SR_ATMOS_OPACITY_filtering,Water,Snow,project_ID) for chunk in chunks)
    if all(gdf.empty for gdf in gdfs):
        print("Job failed, need more images or sample points")
        return pd.DataFrame(), logs
    gdfs=[gdf for gdf in gdfs if not gdf.empty]
    big_gdf=gpd.GeoDataFrame(pd.concat(gdfs, ignore_index=True), crs=gdfs[0].crs)
    if big_gdf.empty:
        big_gdf=pd.DataFrame()
        print("Warning: gdf is empty for this set of points. Consider increasing number of samples")
        logs.append("gdf is empty for this set of points. Consider increasing number of samples")
        return big_gdf, logs
    big_gdf=remove_outliers(big_gdf)
    big_gdf.columns=[col.replace("LS7","L7").replace("LS8","L8") for col in big_gdf.columns]
    return big_gdf,logs
