# LEOHS: Landsat ETM+ OLI Harmonization Script

**LEOHS** is a Python package for harmonizing Landsat 7 and 8 imagery using Google Earth Engine (GEE).
The harmonization models generated from this tool can be used for long term Landsat time series analysis.
LEOHS is designed specifically to create harmonization functions optimized for **user-defined study areas, time periods, and sampling parameters**.
LEOHS can build harmonization functions from either **image pairs** (default) or **image composites**.
A single run of the LEOHS tool using image pairs takes less than 2 EECU-hour, while using the tool for image composites can take considerably more compute 
(depending on AOI size, number of months and years, and cloudy pixel %). It is recommended to use fewer sample points (e.g. 100,000) for image composite harmonization functions.

Related publications:
- (LEOHS tool paper) **[A tool for global and regional Landsat 7 and Landsat 8 cross-sensor harmonization](https://doi.org/10.1080/10106049.2025.2538108)**
- **[Seasonality and Aerosol Optical Thickness Affect Landsat 7 and 8 Harmonization Performance](https://doi.org/10.5194/isprs-annals-XI-2-2026-925-2026)**
- **[Incorporating Multiple Bands and Land Cover Improves Cross-Sensor Normalization](https://doi.org/10.1016/j.rsase.2026.102305)**
---

##  Requirements

- **Python 3.13**
- an active **Google Earth Engine** account
- an area of interest shapefile

---

## Installation

### 1. Create a clean Python 3.13 environment (recommended name: `leohs_env`)
```bash
conda create -n leohs_env python=3.13 -y
conda activate leohs_env
```
### 2. Install LEOHS
```bash
pip install leohs
```

## Example Usage
Before using LEOHS, you must import both `ee` and `leohs`, then **authenticate and initialize** your Google Earth Engine (GEE) session. Only after that should you call `leohs.run_leohs(...)`.
```python
import ee
import leohs
ee.Authenticate() #need to authenticate GEE
ee.Initialize(project="your-earth-engine-project-id") #need to initialize GEE
leohs.run_leohs(
    Aoi_shp_path=r"E:\Canada.shp",
    Save_folder_path=r"E:\Canada_output",
    SR_or_TOA="SR",
    months=[6,7,8],
    years=[2018],
    sample_points_n=100000,
    project_ID="your-earth-engine-project-id")
```
To use image composites instead of image pairs, add the `composite_models` parameter (e.g. `composite_models="median"`).

## `run_leohs` Parameters

- `project_ID` *(str, optional, default=None)*:  
  Your Google Earth Engine Project ID for GEE initialization. 
- `Aoi_shp_path` *(str)*:  
  Path to your input AOI shapefile.
- `Save_folder_path` *(str)*:  
  Path to the output folder where results will be saved.
- `SR_or_TOA` *(str)*:  
  Type of Landsat imagery to process. Choose `"SR"` or `"TOA"`.
- `months` *(list of int)*:  
  List of months to include in image filtering (e.g., `[1,2,3,4,5,6,7,8,9,10,11,12]`).
- `years` *(list of int)*:  
  List of years to include in filtering (e.g., `[2013,2014,2015,2016,2017,2018,2019,2020,2021,2022]`).
- `maxCloudCover` *(int, optional, default=50)*:  
  Maximum cloud cover (%) for image filtering.
- `sample_points_n` *(int)*:  
  Number of sample points to generate (e.g., `100000`). Max: **1,000,000**.
- `shp` *(bool, optional, default=False)*:  
  if True, this parameter will create a shapefile of all the sampled pixels with Landsat values.
- `Regression_types` *(list of str, optional, default=["OLS"])*:  
  List of linear regression models to run. Valid values: `"OLS"`, `"RMA"`, `"TS"`.
- `XGB_models` *(bool, optional, default=False)*:  
If set to True, LEOHS will tune multi-band XGBoost models to predict OLI band values from ETM+ data.
- `CFMask_filtering` *(bool, optional, default=True)*:  
  Whether to apply CFMask filtering (cloud, water, snow masking).
- `Water` *(bool, optional, default=True)*:  
  Allow water pixels (only activated if `CFMask_filtering=True`).
- `Snow` *(bool, optional, default=True)*:  
  Allow snow pixels (only activated if `CFMask_filtering=True`).
- `SR_ATMOS_OPACITY_filtering` *(bool or float, optional, default=False)*:  
  Whether to apply SR_ATMOS_OPACITY filtering. If desired, define atmospheric opacity value to serve as the maximum for this filter (e.g. 0.1). By setting a filter value, the output CSV will include scaled ATMOS_OPACITY values.
If the user sets this value to True, the filter will only keep AOT values <0.3, allowing average and clear pixels.
- `Deep` *(bool, optional, default=True)*:  
  Increases the number of image pairs sampled. Not used when `composite_models` is activated.
- `composite_models` *(str or bool, optional, default=False)*:  
  If False, LEOHS uses image pairs. If set to a composite method, LEOHS builds a per-pixel composite for Landsat 7 and Landsat 8 from all valid images within the selected months and years, and uses these composites to create the harmonization functions. Available methods:
  - `"mean"`: per-band mean of all valid observations.
  - `"median"`: per-band median of all valid observations.
  - `"medoid"`: selects the observation that minimizes the sum of Euclidean distances to all other observations across the six bands (Flood, 2013).
  - `"nlcd"`: computes a pseudo-median observation from the per-band medians, then selects the observation with the lowest squared Euclidean distance to it (Jin et al., 2023).
  - `"p_XX"`: per-band XXth percentile of all valid observations, where XX is any value from 0 to 100 (e.g. `"p_20"` for the 20th percentile, `"p_12.5"`). Values are linearly interpolated between observations; `"p_50"` is equivalent to the median.
  - `"max_ndvi"`: selects the observation with the highest NDVI.
  - `"max_rnb"`: selects the observation with the highest ratio of NIR to blue reflectance (Qiu et al., 2023).


## Outputs

The following files are exported to the specified `Save_folder_path`:

- **Text log** (`SR_LEOHS_harmonization.txt` or `TOA_LEOHS_harmonization.txt`):  
  Contains regression equations for each band, processing time, and diagnostic logs.

- **Heatmaps** (`.png` files):  
  Visualizations of pixel distributions between Landsat 7 and 8 for each band.

- **Pixel and pair data** (`.csv`) and (`.shp`):  
  Sampled pixel values and image names for all matched images. If shp==True, a shapefile will also be saved. For image composites, the file contains the composite band values for each sample point.


## Known Issues

- **Google Earth Engine computation timeout**  
  Occasionally, you may encounter an `ee.EEException: Computation timed out` error. This can happen when GEE servers are under heavy load. **Recommended fix**: Simply wait a bit of time, and re-run `leohs.run_leohs(...)`. The issue usually resolves itself on retry.
- **Performance and speed**  
  The runtime of LEOHS depends on Google Earth Engine load, the number of available CPU cores, the number of sample points, and whether you use image composites.
- **AOI must intersect a WRS-2 Overlap**  
  The tool will stop if your Area of Interest (AOI) does **not intersect with any WRS-2 Overlap zones**.   You can find a shapefile of valid WRS-2 Overlaps in the [LEOHS GitHub repository](https://github.com/galenrichardson/LEOHS).
- **No available images**  
  LEOHS will stop if there are **no valid Landsat images** available that match your AOI, time range or cloud cover threshold.
- **Google Colab**  
  Presently LEOHS does not work in Google Colab due to dependency issues. This functionality might be added at a later date. 

### Additional Resources
Additional scripts for applying LEOHS, as well as global harmonization equations, can be found in the [LEOHS GitHub repository](https://github.com/galenrichardson/LEOHS).
### Latest Update for >=1.3
- Added image composite harmonization with the `composite_models` parameter.
- Bug fixes and minor reliability improvements.
### Update for >=1.2
- LEOHS runs in Python 3.13 instead of 3.10.
- Updated East/West point sampling strategy to minimize effect of BRDF.
### References
- Flood, N. (2013). Seasonal composite Landsat TM/ETM+ images using the medoid (a multi-dimensional median). *Remote Sensing*.
- Jin, S., et al. (2023). National Land Cover Database 2019: A new strategy for creating clean leaf-on and leaf-off Landsat composite images. *Journal of Remote Sensing*.
- Qiu, S., et al. (2023). Evaluation of Landsat image compositing algorithms. *Remote Sensing of Environment*.
### License
This project is licensed under the  
**GNU General Public License v3.0 or later (GPL-3.0-or-later)**  
© 2025 Galen Richardson
